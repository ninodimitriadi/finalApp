package com.example.fragments.Fragments

import androidx.fragment.app.Fragment
import com.example.signsloginfinall.R

class PersonFragment : Fragment(R.layout.fragment_person) {
}